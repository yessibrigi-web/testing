"""
Prueba: Instalar Addon
"""

def ejecutar(pagina, frame, on_paso=None):

    pagina.wait_for_timeout(3000)

    # Clic en ADPRO
    pagina.get_by_title("Administración de proyectos").click()
    pagina.wait_for_timeout(2000)
    if on_paso: on_paso("ADPRO")

    # Esperar menú visible
    pagina.wait_for_selector("div.menu-caja:visible", timeout=30000)
    pagina.wait_for_timeout(1000)

    # Clic en Mantenimiento
    pagina.evaluate("""
        () => {
            const items = document.querySelectorAll('div.menu-caja');
            for (const item of items) {
                if (item.getAttribute('title') === 'Ruta: ADPRO/Mantenimiento') {
                    item.click(); break;
                }
            }
        }
    """)
    pagina.wait_for_timeout(1000)
    if on_paso: on_paso("Mantenimiento")

    # Clic en CONFIGURACION
    pagina.evaluate("""
        () => {
            const items = document.querySelectorAll('div.menu-caja');
            for (const item of items) {
                if (item.getAttribute('title') === 'Ruta: ADPRO/Mantenimiento/CONFIGURACION') {
                    item.click(); break;
                }
            }
        }
    """)
    pagina.wait_for_timeout(1000)
    if on_paso: on_paso("CONFIGURACION")

    # Clic en Addons
    pagina.evaluate("""
        () => {
            const items = document.querySelectorAll('div.menu-caja');
            for (const item of items) {
                if (item.getAttribute('title') === 'Ruta: ADPRO/Mantenimiento/CONFIGURACION/Addons') {
                    item.click(); break;
                }
            }
        }
    """)
    pagina.wait_for_load_state("networkidle")
    pagina.wait_for_timeout(3000)
    if on_paso: on_paso("Addons")

    frame = pagina.locator("#pagina1").content_frame

    # Recargar solo si la página no cargó
    pagina.wait_for_timeout(5000)
    try:
        btn = frame.locator("#btnRecargar")
        if btn.is_visible():
            btn.click()
            pagina.wait_for_timeout(3000)
            if frame.locator("#btnRecargar").is_visible():
                frame.locator("#btnRecargar").click()
                pagina.wait_for_timeout(3000)
        if on_paso: on_paso("Addons cargado")
    except Exception:
        pass

    # Hover sobre el primer registro para que aparezca el botón Activar
    frame.locator(".MuiAccordionSummary-root").first.hover()
    pagina.wait_for_timeout(500)

    # Clic en el botón Activar
    frame.locator(".btn-activar").first.click()
    pagina.wait_for_timeout(1000)
    if on_paso: on_paso("Activar")
    pagina.wait_for